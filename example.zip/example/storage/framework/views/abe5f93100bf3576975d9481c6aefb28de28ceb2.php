<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
       
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .center {
             margin-left: auto;
             margin-right: auto;
            }
        </style>
         <!-- Script -->
   
    </head>
    <body>
    <div class="container" style="text-align: center;">
    <h2>Stock pricing of the selected index</h2>
            <div class="form-group">
                <label for="index">Select Index:</label>
                <select name="sel_depart" id="sel_depart" class="form-control" style="width:250px">
                    <option value="1">NIFTY 50</option>
                    <option value="2">BANK NIFTY</option>
                    </select>
            <br><br>
               
                <table class="center" id="sel_emp" border = "1">
                <tr>
                <th>Symbol</th>
                <th>High</th>
                <th>Low</th>
                <th>Open</th>
                <th>Close</th>
              <!--  <td>Stockdatetime</td>-->
                </tr>
                <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                <td><?php echo e($user->symbol); ?></td>
                <td><?php echo e($user->high); ?></td>
                <td><?php echo e($user->low); ?></td>
                <td><?php echo e($user->open); ?></td>
                <td><?php echo e($user->close); ?></td>
               <!-- <td><?php echo e($user->stockdatetime); ?></td>-->
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
                <script type='text/javascript'>

                $(document).ready(function(){


                $('#sel_depart').change(function(){

                    var id = $(this).val();
                 
                    // AJAX request 
                    $.ajax({
                    url: 'getEmployees/'+id,
                    type: 'get',
                    dataType: 'json',
                    success: function(response){
                        $("#sel_emp").html(response);
                        var len = 0;
                        len=response.length;
                        if(len > 0){
                        // Read data and create <option >
                       
                        var out = "<table>";
                out+="<tr><th>Symbol</th><th>High</th><th>Low</th><th>Open</th><th>Close</th></tr>";//TABLE HEADER/HEADING----------
                        for(var i=0; i<len; i++){

                            var id = response[i].id;
                            var symbol = response[i].symbol;
                            var high = response[i].high;
                            var low = response[i].low;
                            var open = response[i].open;
                            var close = response[i].close;
                            var stockdatetime = response[i].stockdatetime;
                           
                            out += "<tr><td>" + symbol +
                             "</td><td>" +high +
                            "</td><td>" + low +
                            "</td><td>" + open +
                             "</td><td>" + close +
                            "</td></tr>";
                            out += "</table>";
                        document.getElementById("sel_emp").innerHTML = out;
                        }
                        }

                    }
                    });
                });

                });

                </script>
                    </div>
                    </div>
                    </body>
                </html>
<?php /**PATH C:\xampp\htdocs\example\resources\views/welcome.blade.php ENDPATH**/ ?>