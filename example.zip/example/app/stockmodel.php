<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class stockmodel extends Model
{
    //
    public static function getuserData(){

       $value = DB::table('stockmodels')
       ->where('masterid', '1')
       ->orderBy('id', 'DESC')
       ->get();      
       
       return $value;
      }
}
