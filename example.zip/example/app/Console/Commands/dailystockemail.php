<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use PHPMailer\PHPMailer;
use DB, Hash, Mail;
use DateTime;
use PHPExcel; 
use PHPExcel_IOFactory;
use PHPExcel_Style_Alignment;
use PHPExcel_Style_Border;
use PHPExcel_Style_Fill;

class dailystockemail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'get:stockdata';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send stock price on email';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $datetime = date('Y-m-d H:i:s');
        $strMessage ="Please find ";//array();
        $strMessagetest=array();
        $symbol=array();
        $high=array();
        $result = DB::table('stockmodels')->get(); 
        $rowscount = $result->count();
        $jsonData = json_decode(json_encode($result),true);
        // $jsonData =(json_encode($result));
     
                         
        $emp_emailid='surajmonde@gmail.com';
        $Subject="Stock Price Report";
         // generate xls file 
         $filepath = $this->Exportcsv($jsonData,$rowscount);
        $BodyContent="Dear Sir, <br> Please find attached stock report";
         // Send New  password code starts here...     
        // echo "return $filepath";   
        $mailid=$emp_emailid;
        $mail = new PHPMailer\PHPMailer(); //create
        $mail->isSMTP();
        //$mail->SMTPDebug = 2;
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 587;
        $mail->SMTPAuth = true;
        $mail->Username = 'mondesuraj8819@gmail.com';
        $mail->Password = 'blaze@508';
        $mail->From = $mailid;
        $mail->FromName = 'StockMarket';
        $mail->addAddress($mailid);
        $mail->addAttachment($filepath);
        $mail->addReplyTo('surajmonde@gmail.com');
        $mail->WordWrap = 50;
        $mail->isHTML(true);
        $mail->Subject =  $Subject;
        $mail->Body    =  $BodyContent; 
                             
        $mail->Message =''; 
     
        if(!$mail->send()) {
          
            echo 'Message could not be sent.';
            
            echo 'Mailer Error: ' . $mail->ErrorInfo;
            exit;
         }
    }
    public function Exportcsv($jsondata,$rowscount){
        
        $folderpath = "H:\Excelfile";

     //Create a PHPExcel object
      $objPHPExcel = new PHPExcel();
 
             //Set document properties
     $objPHPExcel->getProperties()->setCreator("Mitrajit Samanta")
                     ->setLastModifiedBy("Mitrajit Samanta")
                     ->setTitle("User's Information")
                     ->setSubject("User's Personal Data")
                     ->setDescription("Description of User's")
                     ->setKeywords("")
                     ->setCategory("");
 
                     // Set default font
      $objPHPExcel->getDefaultStyle()->getFont()->setName('Arial')->setSize(10);

      //Set the first row as the header row	
      $objPHPExcel->getActiveSheet()
      ->setCellValue('A3', 'Symbol')  
      ->setCellValue('B3', 'High')    
      ->setCellValue('C3', 'Low')   
      ->setCellValue('D3', 'Open')
      ->setCellValue('E3', 'Close');							  
     // ->setCellValue('F3', 'Stockdatetime');
      //Rename the worksheet 
     $objPHPExcel->getActiveSheet()->setTitle('Stock INFO');
     
     //Set active worksheet index to the first sheet, so Excel opens this as the first sheet
     $objPHPExcel->setActiveSheetIndex(0);								
     $sheet_application = $objPHPExcel->getActiveSheet ( 0 );
     $sheet_application->setTitle ( "StockReport" );
     $sheet_application  ->mergeCells('A1:C1');

     $i = 3;        
    
     $count = $rowscount;//count($jsondata);

     for($j=0; $j<$count; $j++) {        
      
       $symbol = $jsondata[$j]['symbol'];
       $high =   $jsondata[$j]['high'];
       $low =    $jsondata[$j]['low'];
       $open =   $jsondata[$j]['open'];      
       $close =  $jsondata[$j]['close'];
       //$stockdatetime =  $jsondata[$j]['stockdatetime'];  
       
         $objPHPExcel->getActiveSheet()
         ->setCellValue('A'.($i+1), $symbol)
         ->setCellValue('B'.($i+1), $high)
         ->setCellValue('C'.($i+1), $low)												 
         ->setCellValue('D'.($i+1), $open)
         ->setCellValue('E'.($i+1), $close);
       //  ->setCellValue('F'.($i+1), $stockdatetime);        
	 						  

         $i++;	
     }     


     $sheet_application->setCellValue ( "A1", "Stock Report" );
     
     /* START - BLOCK Style*/                  
     $align_text = array(
         'alignment' => array(
         'horizontal' => PHPExcel_Style_Alignment::HORIZONTAL_CENTER,
     ));
     $border = array ();
     $border['borders']=array();
     $border['borders']['allborders']=array();
     $border['borders']['allborders']['style']=PHPExcel_Style_Border::BORDER_THIN ;
     $background['fill']=array();
     $background['fill']['type']=PHPExcel_Style_Fill::FILL_SOLID;
     $background['fill']['color']=array();
     $background['fill']['color']['rgb']='9fa1a5';        
     $sheet_application->getStyle ( "A3:E3" )->applyFromArray ($border);
     $sheet_application->getStyle ( "A3:E3" )->applyFromArray ($align_text);        
     $sheet_application->getStyle ( "A3:E3" )->applyFromArray ($background); 
     

     $sheet_application ->getColumnDimension ( "A" )->setAutoSize ( true );
     $sheet_application ->getColumnDimension ( "B" )->setAutoSize ( true );
     $sheet_application ->getColumnDimension ( "C" )->setAutoSize ( true );
     $sheet_application ->getColumnDimension ( "D" )->setAutoSize ( true );
     $sheet_application ->getColumnDimension ( "E" )->setAutoSize ( true );
     //$sheet_application ->getColumnDimension ( "F" )->setAutoSize ( true );
    //Dynamic name, the combination of date and time
         $filename = 'StockReport'."_".date('jMY').".xls";				
                 
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
                 
         //$oldumask = umask(0); 
         $filepath = $folderpath."/".$filename;
        // echo $filepath;         
         $objWriter->save($filepath);	                         
         $str = str_replace('.php', '.xls', $filename);										
         
             "Create $str file Successfully" . PHP_EOL;	
         
           return $filepath;

    }
}
